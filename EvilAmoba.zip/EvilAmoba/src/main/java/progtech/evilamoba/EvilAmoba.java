package progtech.evilamoba;

/**
 * @author Molnár Márk
 */
public class EvilAmoba {

    public static void main(String[] args) {
        GameController.startGame();
    }
}
